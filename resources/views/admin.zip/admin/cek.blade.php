<!DOCTYPE html>
<html>
<head>
	<title>Cek</title>
</head>
<body>
	<h1>{{ $id }}</h1>
</body>
</html>